package com.manage.service.Impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.manage.common.Const;
import com.manage.common.LayUiPageResponse;
import com.manage.common.LayUiResponse;
import com.manage.common.ServerResponse;
import com.manage.dao.CartMapper;
import com.manage.dao.GoodsMapper;
import com.manage.dao.OrderMapper;
import com.manage.dao.UserMapper;
import com.manage.pojo.Cart;
import com.manage.pojo.Goods;
import com.manage.pojo.Order;
import com.manage.pojo.User;
import com.manage.service.IOrderService;
import com.manage.util.PublicUtil;
import com.manage.vo.OrderVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrderServiceImpl implements IOrderService {


    @Autowired
    private UserMapper userMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private CartMapper cartMapper;
    @Autowired
    private GoodsMapper goodsMapper;

    //前端客户下单
    public ServerResponse portalAddOrder(Order order) {

        String userCode = order.getUserCode();
        User user = userMapper.findUserByUserCode(userCode);
        order.setUserName(user.getUserName());
        order.setUserPhone(user.getUserPhone());
        String orderCode = PublicUtil.setCode("O");
        order.setOrderCode(orderCode);
        order.setOrderCreateTime(new Date());
        int count = orderMapper.insertSelective(order);
        if (count > 0) {
            String cartIdsString = order.getCartIds();
            String[] ids= cartIdsString.split(",");
            List<Integer> idList =new ArrayList();
            for(String s : ids){
                Integer i = Integer.parseInt(s);
                //商品表的商品购买数量加+1
                Cart cart = cartMapper.selectByPrimaryKey(i);
                Goods goods = goodsMapper.selectByPrimaryKey(cart.getGoodsId());
                goods.setGoodsBuyNum(goods.getGoodsBuyNum() + 1);
                goodsMapper.updateByPrimaryKeySelective(goods);
                idList.add(i);
            }
            int updateCount = cartMapper.updateCartSettlementType(idList);
            if (updateCount > 0) {
                return ServerResponse.createBySuccessMessage("下单成功");
            } else {
                return ServerResponse.createByErrorMessage("更新购物车失败");
            }
        } else {
            return ServerResponse.createByErrorMessage("下单失败");
        }
    }
    //后台查询全部订单根据角色
    public LayUiPageResponse findOrderByRole(HttpServletRequest request,Integer userRole, Integer page, Integer limit ,OrderVo orderVo) {

        if (userRole == 1) {
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findAllOrder(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else if (userRole == 2) {
            User user = (User) request.getSession().getAttribute(Const.ManagerToken.SESSION);
            orderVo.setUserCode(user.getUserCode());
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findAllOrder(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else {
            return LayUiPageResponse.createByErrorMessage("暂无数据");
        }
    }
    //后台查询全部未发货订单根据角色
    public LayUiPageResponse findOrderByRoleAndUnshippend(HttpServletRequest request,Integer userRole, Integer page, Integer limit, OrderVo orderVo) {

        if (userRole == 1) {
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndUnshippend(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else if (userRole == 2) {
            User user = (User) request.getSession().getAttribute(Const.ManagerToken.SESSION);
            orderVo.setUserCode(user.getUserCode());
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndUnshippend(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else {
            return LayUiPageResponse.createByErrorMessage("暂无数据");
        }

    }
    //后台查询全部已发货订单根据角色
    public LayUiPageResponse findOrderByRoleAndShippend(HttpServletRequest request,Integer userRole, Integer page, Integer limit, OrderVo orderVo) {

        if (userRole == 1) {
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndShippend(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else if (userRole == 2) {
            User user = (User) request.getSession().getAttribute(Const.ManagerToken.SESSION);
            orderVo.setUserCode(user.getUserCode());
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndShippend(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else {
            return LayUiPageResponse.createByErrorMessage("暂无数据");
        }

    }
    //后台查询配送完成订单根据角色
    public LayUiPageResponse findOrderByRoleAndDelivery(HttpServletRequest request,Integer userRole, Integer page, Integer limit, OrderVo orderVo) {

        if (userRole == 1) {
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndDelivery(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else if (userRole == 2) {
            User user = (User) request.getSession().getAttribute(Const.ManagerToken.SESSION);
            orderVo.setUserCode(user.getUserCode());
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndDelivery(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else {
            return LayUiPageResponse.createByErrorMessage("暂无数据");
        }

    }
    //后台查询退货订单根据角色
    public LayUiPageResponse findOrderByRoleAndReturn(HttpServletRequest request,Integer userRole, Integer page, Integer limit, OrderVo orderVo) {

        if (userRole == 1) {
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndReturn(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else if (userRole == 2) {
            User user = (User) request.getSession().getAttribute(Const.ManagerToken.SESSION);
            orderVo.setUserCode(user.getUserCode());
            PageHelper.startPage(page, limit);
            List<Order> orderList = orderMapper.findOrderByRoleAndReturn(orderVo);
            if (orderList.size() > 0) {
                PageInfo pageInfo = new PageInfo(orderList);
                return LayUiPageResponse.createBySuccess(orderList, pageInfo.getTotal(), page, limit);
            } else {
                return LayUiPageResponse.createByErrorMessage("暂无数据");
            }
        } else {
            return LayUiPageResponse.createByErrorMessage("暂无数据");
        }

    }

    //删除订单
    public ServerResponse deleteOrder(Integer orderId) {

        int count = orderMapper.deleteByPrimaryKey(orderId);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("删除成功");
        } else {
            return ServerResponse.createByErrorMessage("删除失败");
        }

    }
    //批量删除订单
    public ServerResponse someDeleteOrder(String ids) {

        int i = ids.indexOf("[");
        int j = ids.indexOf("]");
        String s1 = ids.substring(i + 1, j);
        String[] idsArray= s1.split(",");
        List<Integer> idList =new ArrayList();
        for(String s : idsArray){
            Integer k = Integer.parseInt(s);
            idList.add(k);
        }
        int count = orderMapper.someDeleteOrder(idList);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("删除成功");
        } else {
            return ServerResponse.createByErrorMessage("删除失败");
        }
    }

    //修改订单前的详请
    public ServerResponse modifyOrder(Integer orderId) {

        Order order = orderMapper.selectByPrimaryKey(orderId);
        if (order != null) {
            return ServerResponse.createBySuccess("找到该订单", order);
        } else {
            return ServerResponse.createByErrorMessage("未找到该订单");
        }
    }
    //保存订单
    public ServerResponse saveOrder(Order order) {

        order.setOrderUpdateTime(new Date());
        int count = orderMapper.updateByPrimaryKeySelective(order);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("保存成功");
        } else {
            return ServerResponse.createByErrorMessage("保存失败");

        }
    }
    //发货订单
    public ServerResponse sendOrder(Integer orderId) {

        int count = orderMapper.sendOrder(orderId);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("发货成功");
        } else {
            return ServerResponse.createByErrorMessage("发货失败");
        }

    }
    //退货订单
    public ServerResponse rebackOrder(Integer orderId) {
        int count = orderMapper.rebackOrder(orderId);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("退货成功");
        } else {
            return ServerResponse.createByErrorMessage("退货失败");
        }
    }
    //确认收货订单
    public ServerResponse confirmOrder(Integer orderId) {
        int count = orderMapper.confirmOrder(orderId);
        if (count > 0) {
            return ServerResponse.createBySuccessMessage("确认成功");
        } else {
            return ServerResponse.createByErrorMessage("确认失败");
        }
    }

    //订单详情
    public LayUiPageResponse detailOrder(Integer orderId, Integer page,Integer limit) {

        Order order = orderMapper.selectByPrimaryKey(orderId);
        String cartIds = order.getCartIds();
        String[] idsArray= cartIds.split(",");
        List<Integer> idList =new ArrayList();
        for(String s : idsArray){
            Integer k = Integer.parseInt(s);
            idList.add(k);
        }
        PageHelper.startPage(page, limit);
        List<Cart> cartList = cartMapper.getCartListByIds(idList);
        String photoPath = "http://127.0.0.1:8080/upload/";
        for (int i = 0; i < cartList.size(); i++) {
            cartList.get(i).setGoodsImg(photoPath + cartList.get(i).getGoodsImg());
        }
        PageInfo pageInfo = new PageInfo(cartList);
        return LayUiPageResponse.createBySuccess(cartList, pageInfo.getTotal(), page, limit);

    }
}
