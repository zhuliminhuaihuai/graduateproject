
var navs = [{
	"title" : "后台首页",
	"icon" : "icon-computer",
	"href" : "manage/user/main.html",
	"spread" : false
},{
    "title" : "就业信息管理",
    "icon" : "&#xe604;",
    "href" : "",
    "spread" : false,
    "children" : [
        {
            "title" : "学生就业情况",
            "icon" : "&#xe60a;",
            "href" : "/manage/user/toUserList",
            "spread" : false
        },
        {
            "title" : "学生简历投递情况",
            "icon" : "&#xe63c;",
            "href" : "/manage/user/toUserList",
            "spread" : false
        },
        {
            "title" : "学生简历列表",
            "icon" : "&#xe63c;",
            "href" : "/manage/user/toUserList",
            "spread" : false
        },
    ]
},{
	"title" : "企业管理",
	"icon" : "&#xe60b;",
	"href" : "",
	"spread" : false,
	"children" : [
		{
			"title" : "企业列表",
			"icon" : "&#xe857;",
			"href" : "/manage/work/work_system_list.html",
			"spread" : false
		},
		{
			"title" : "招聘信息列表",
			"icon" : "&#xe63c;",
			"href" : "/manage/work/work_order_list.html",
			"spread" : false
		},
	]
},{
    "title" : "系统管理",
    "icon" : "&#xe614;",
    "href" : "",
    "spread" : false,
    "children" : [
        {
            "title" : "学生用户管理",
            "icon" : "&#xe66f;",
            "href" : "/manage/user/student_list",
            "spread" : false
        },
        {
            "title" : "企业用户管理",
            "icon" : "&#xe612;",
            "href" : "/manage/user/enter_list",
            "spread" : false
        },
    ]
},]
